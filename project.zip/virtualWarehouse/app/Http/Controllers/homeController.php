<?php

namespace App\Http\Controllers;
use App\Http\Controllers\Controller; 
use Illuminate\Http\Request;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\DB;

//use Illuminate\Http\Request;

class homeController extends Controller
{
	// ======================register==========================>
   //  public function store(request $request)
   //  {
   //  	//echo "llll";
		 //    $name=$request->input('name');
			// $password=$request->input('password');
			// $email=$request->input('email');
			// echo DB::insert('insert into users(id,name,email,password) value(?,?,?,?)',[null,$name,$email,$password]);
			// $data = DB::select("select * from users");
			// echo "<pre>";
			// print_r($data);
   //  }
 //==============================================================>


  public function shows()
  {
 	return view('login');
 }





 // ====================================login======================
 
 // 	public function log(request $request)

 // {
 // 	//echo "done";

 // 	$name=$request->input('name');
	// $password=$request->input('password');
	// //$email=$request->input('email');
	// // DB::insert('insert into users(id,name,email,password) value(?,?,?,?)',[null,$name,$email,$password]);
	// $data = DB::select ('select id from users WHERE name=? and password=?',[$name,$password]);
	// echo "<pre>";
	// print_r($data);
//==========================================================
	// // $sql = "SELECT * FROM userinfo WHERE Username='$request->username' AND Password='$request->password'";
 //        //$res = DB::select($sql);
 //
//==================================================================

 // }


}
