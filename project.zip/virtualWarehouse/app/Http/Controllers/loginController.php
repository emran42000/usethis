<?php

namespace App\Http\Controllers;
use App\Http\Controllers\Controller; 
use Illuminate\Http\Request;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\DB;

class loginController extends Controller
{
	//==============login=====================================>
   public function log(request $request)

 {
 	//echo "done";

 	$name=$request->input('name');
	$password=$request->input('password');
	//$email=$request->input('email');
	// DB::insert('insert into users(id,name,email,password) value(?,?,?,?)',[null,$name,$email,$password]);
	 $data = DB::select ('select id from users WHERE name=? and password=?',[$name,$password]);
	// echo "<pre>";
	//print_r($data);
	 if (count($data)) {
	 	echo "welcome";
	 }
	 else{

	 	return view('register');
	 }

	// $sql = "SELECT * FROM userinfo WHERE Username='$request->username' AND Password='$request->password'";
        //$res = DB::select($sql);
	//............................
	 //  $data['data'] = DB::table('users')->get();
	//.....................

	 return view('adminHome');
	   //return view('userInfo');

 }
//===============================End=============================================>

 //=======================register=================================>


  public function store(request $request)
    {
    	
		    $name=$request->input('name');
			$password=$request->input('password');
			$email=$request->input('email');
			echo DB::insert('insert into users(id,name,email,password) value(?,?,?,?)',[null,$name,$email,$password]);
			// $data = DB::select("select * from users");
			// echo "<pre>";
			// print_r($data);
			return view('login');
    }
//====================userINFO=======================================>
    public function user()
    {
    	$data['data'] = DB::table('users')->get();
    	// echo "<pre>";
    	// print_r($data)	;
    	if (count($data)) {
    		return view('user',$data);
    	}
    	else{
    		echo "problems";
    	}
    	
    }
  //===================END================================================>

public function delete($id)
{
	DB::table('users')->WHERE('id',$id)->delete();
	return redirect('/user');
}







  }
