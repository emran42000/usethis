<?php
namespace App\Http\Controllers;
use App\Http\Controllers\Controller; 
use Illuminate\Http\Request;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\DB;



class categoryController extends Controller
{
    public function category()
    {
    	return view('categories');
    }
    public function su(request $request)
   {
   // echo "<pre>";
   // 	print_r($request->input());
   	//===============>
   	$categoryName=$request->input('categoryName');
   	$shortDescription=$request->input('shortDescription');
   	$publicationStatus=$request->input('publicationStatus');
   	echo DB::insert('insert into categories(id,categoryName,shortDescription,publicationStatus) value(?,?,?,?)',[null,$categoryName,$shortDescription,$publicationStatus]);


///////////////////////////////////////////////////////////////////
   	
   	

   	 $data = DB::select("select * from categories");
   	 echo "<pre>";
   	 print_r($data);
}

//==============================>
 public function data(){
 	$data['data'] = DB::table('categories')->get();
    	// echo "<pre>";
    	// print_r($data)	;
    	if (count($data)) {
    		return view('cat',$data);
    	}
    	else{
    		echo "problems";
    	}
    	






}



}
