<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class registerController extends Controller
{
 public function show(){
 	return view('register');
 }
 // public function shows(){
 // 	return view('login');
 // }


 
}
