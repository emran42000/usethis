<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<br><br>
	<center>
		<table border="1" cellpadding="5" cellspacing="0">
		<tr><td colspan="4" align="CENTER">Users</td></tr>
		<tr>
			<td>ID</td>

			<td>Name</td>
			<td>Email</td>
		</tr>
		
	</center>
     
		<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			
			<td> <?php echo e($value->id); ?></td>
			<td> <?php echo e($value->name); ?></td>
			<td> <?php echo e($value->email); ?></td>
			<td><a href="#"><button>Edit</button></a>&nbsp;<a href="/delete/<?php echo e($value->id); ?>"><button>Delete</button></a></td>
			
			
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





	</table>
	<a href="login">back</a>
</body>
</html>
<?php echo $__env->make('adminHome', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>