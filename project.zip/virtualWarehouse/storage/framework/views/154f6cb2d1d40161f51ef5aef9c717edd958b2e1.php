<!DOCTYPE html>
<html>
<head>
	<title></title>





<body>
	<center>

	<table border="1" cellpadding="5" cellspacing="0">
		<tr><td colspan="4" align="CENTER">categoryInfo</td></tr>

          <tr>
			<td>ID</td>
			<td>CategorieName</td>
            <td>shortDescription</td>
			<td>publicationStatus</td>
			<td>Action</td>
			
		</tr>
		<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			
			<td> <?php echo e($value->id); ?></td>
			<td> <?php echo e($value->categoryName); ?></td>
			<td> <?php echo e($value->shortDescription); ?></td>
			<td> <?php echo e(($value->publicationStatus == 1)? 'published' : 'unpublished'); ?></td>



			<td><a href="#"><button>Edit</button></a>&nbsp;<a href=""><button>Delete</button></a></td>
			
			
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		
</table>

</center>

</body>
</html>