<!DOCTYPE html>
<html>
<head>
	<title>categories</title>
</head>
<body>
	<br><br>

	   <center>
	   	 <form action="/category" method="POST">
			
			CategorieName:<input type="text" name="categoryName" id="">
			<br><br>
			Description:<input type="text" name="shortDescription">

			<br><br>
		
			<label>Publication Status</label>
			
            <select name="publicationStatus">
				<option value="1"  >publised</option>
				<option value="0" >publisedlater</option>

		    </select>
			<br><br>
		    <input type="hidden" name="token" value="<?php echo e(csrf_token()); ?>">
		    <br><br>
		    <button type="submit" name="button">ADD</button>
	   
	   </form>
	   </center>
	   <br><br>
	   <!-- ========================== -->
	   
         


      

</body>
</html>
<?php echo $__env->make('adminHome', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>