<!DOCTYPE html>
<html>
<head>
  <title>register</title>
</head>
<body>
  <center>
    <br><br>
        <form action="/admin" method="POST">
    
   
    Name:<input type="text" name="name">
    <br><br>
    Password:<input type="password" name="password">
    <br><br>
    <input type="hidden" name="token" value="<?php echo e(csrf_token()); ?>">
    <br><br>
    <button type="submit" name="button">login</button>
    <a href="/register">Go back</a>
  </form>
  </center>
  

</body>
</html>







 <!-- ======================================================== -->
