<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/home', function () {
    return view('welcome');
});
//Route::get('/xxx',)
Route::get("/register",'registerController@show');
Route::post("/submit",'loginController@store');
//==========================================================>
		// Route::post("/submit",'homeController@store');
// ^__^		// Route::get("/login",'registerController@shows');
		// Route::post("/log",'homeController@log');
//============================================================>
Route::get("/login",'homeController@shows');
Route::post("/admin",'loginController@log');
Route::get("/user",'loginController@user');
Route::get("/delete/{id}",'loginController@delete');
//=============Category===============================>
Route::get("/category",'categoryController@category');
Route::post("/category",'categoryController@su');
Route::get("/cat",'categoryController@data');

