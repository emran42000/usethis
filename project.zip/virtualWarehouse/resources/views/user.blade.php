
@extends('adminHome')
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<br><br>
	<center>
		<table border="1" cellpadding="5" cellspacing="0">
		<tr><td colspan="4" align="CENTER">Users</td></tr>
		<tr>
			<td>ID</td>

			<td>Name</td>
			<td>Email</td>
		</tr>
		
	</center>
     
		@foreach( $data as $value )
		<tr>
			
			<td> {{ $value->id}}</td>
			<td> {{ $value->name}}</td>
			<td> {{ $value->email}}</td>
			<td><a href="#"><button>Edit</button></a>&nbsp;<a href="/delete/{{ $value->id}}"><button>Delete</button></a></td>
			
			
		</tr>
		@endforeach





	</table>
	<a href="login">back</a>
</body>
</html>