<!DOCTYPE html>
<html>
<head>
  <title>register</title>
</head>
<body>
  <form action="/submit" method="POST">
    
    <!-- {{URL::to('/imran')}} -->
    Name:<input type="text" name="name">
    <br><br>
    Password:<input type="password" name="password">
    <br><br>
    Email:<input type="text" name="email">
    <br><br>
    <input type="hidden" name="token" value="{{csrf_token()}}">
    <button type="submit" name="button">Register</button>
    <a href="/login">Go back Login</a>
  </form>

</body>
</html>