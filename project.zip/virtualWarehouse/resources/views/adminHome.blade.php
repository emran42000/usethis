<!DOCTYPE html>
<html>
<head>
	<title>admin</title>
</head>
<body>
	<br><br>
	<a href="home">Home</a>
	<br><br>
	<a href="category">ADD product</a>
	<br><br>
	<a href="cat">CategoryInfo</a>
	<br><br>
	<!-- <a href="#">Delet user</a>
	<br><br> -->
	<a href="user">User info</a>
	
	
	


</body>
</html>