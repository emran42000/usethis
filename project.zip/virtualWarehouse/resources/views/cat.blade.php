<!DOCTYPE html>
<html>
<head>
	<title></title>





<body>
	<center>

	<table border="1" cellpadding="5" cellspacing="0">
		<tr><td colspan="4" align="CENTER">categoryInfo</td></tr>

          <tr>
			<td>ID</td>
			<td>CategorieName</td>
            <td>shortDescription</td>
			<td>publicationStatus</td>
			<td>Action</td>
			
		</tr>
		@foreach( $data as $value )
		<tr>
			
			<td> {{ $value->id}}</td>
			<td> {{ $value->categoryName}}</td>
			<td> {{ $value->shortDescription}}</td>
			<td> {{ ($value->publicationStatus == 1)? 'published' : 'unpublished'}}</td>



			<td><a href="#"><button>Edit</button></a>&nbsp;<a href=""><button>Delete</button></a></td>
			
			
		</tr>
		@endforeach

		
</table>

</center>

</body>
</html>